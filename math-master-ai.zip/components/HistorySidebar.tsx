
import React from 'react';
import { HistoryItem } from '../types';

interface HistorySidebarProps {
  history: HistoryItem[];
  onSelect: (item: HistoryItem) => void;
  onClear: () => void;
}

const HistorySidebar: React.FC<HistorySidebarProps> = ({ history, onSelect, onClear }) => {
  return (
    <div className="flex flex-col h-full bg-slate-50 border-r border-slate-200 w-full md:w-80">
      <div className="p-6 flex justify-between items-center">
        <h2 className="text-xl font-bold text-slate-800">History</h2>
        {history.length > 0 && (
          <button 
            onClick={onClear}
            className="text-xs text-red-500 hover:text-red-600 font-medium"
          >
            Clear All
          </button>
        )}
      </div>
      
      <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-2">
        {history.length === 0 ? (
          <div className="text-center py-10">
            <p className="text-slate-400 text-sm">No history yet.</p>
          </div>
        ) : (
          history.map((item) => (
            <button
              key={item.id}
              onClick={() => onSelect(item)}
              className="w-full text-left p-3 rounded-lg bg-white border border-slate-200 hover:border-indigo-300 hover:shadow-md transition-all group"
            >
              <p className="text-sm font-semibold text-slate-700 truncate">{item.problem}</p>
              <div className="flex items-center justify-between mt-1">
                <span className="text-[10px] text-slate-400">
                  {new Date(item.timestamp).toLocaleDateString()}
                </span>
                <span className="text-[10px] bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded-full font-medium">
                  {item.solution.topic}
                </span>
              </div>
            </button>
          ))
        )}
      </div>
    </div>
  );
};

export default HistorySidebar;
