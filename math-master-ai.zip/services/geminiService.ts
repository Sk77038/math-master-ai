
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { MathSolution } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const solveMathProblem = async (
  input: string, 
  imageUri?: string
): Promise<MathSolution> => {
  const model = 'gemini-3-pro-preview';
  
  const prompt = `
    You are an expert Math Master AI. Solve the following math problem.
    Provide a comprehensive step-by-step solution.
    
    IMPORTANT: Return the response in RAW JSON format following this schema:
    {
      "problem": "The original problem text",
      "explanation": "A brief overview of the concepts used",
      "steps": ["Step 1 description", "Step 2 description", "..."],
      "finalAnswer": "The final result formatted clearly",
      "graphData": [{"x": -10, "y": 100}, ...], // ONLY include if it is a function (like y=mx+b or y=x^2) that can be plotted. Provide ~20 points.
      "topic": "Algebra/Calculus/etc",
      "difficulty": "Easy/Medium/Hard"
    }
  `;

  let response: GenerateContentResponse;

  if (imageUri) {
    const base64Data = imageUri.split(',')[1];
    const mimeType = imageUri.split(',')[0].split(':')[1].split(';')[0];
    
    response = await ai.models.generateContent({
      model,
      contents: {
        parts: [
          { text: prompt + "\nSolve the problem shown in this image: " + input },
          { inlineData: { data: base64Data, mimeType } }
        ]
      },
      config: {
        responseMimeType: "application/json",
      }
    });
  } else {
    response = await ai.models.generateContent({
      model,
      contents: prompt + "\nProblem: " + input,
      config: {
        responseMimeType: "application/json",
      }
    });
  }

  try {
    const resultText = response.text || "{}";
    return JSON.parse(resultText) as MathSolution;
  } catch (error) {
    console.error("Failed to parse Gemini response", error);
    throw new Error("Could not interpret the mathematical solution. Please try again.");
  }
};
