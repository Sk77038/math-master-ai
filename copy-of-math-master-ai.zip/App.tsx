
import React, { useState, useEffect, useRef } from 'react';
import { solveMathProblem } from './services/geminiService';
import { MathSolution, HistoryItem } from './types';
import HistorySidebar from './components/HistorySidebar';
import GraphView from './components/GraphView';

const App: React.FC = () => {
  const [input, setInput] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [currentSolution, setCurrentSolution] = useState<MathSolution | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load history from localStorage and check for shared links
  useEffect(() => {
    const saved = localStorage.getItem('math_master_history');
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load history", e);
      }
    }

    // Handle deep-linked shared solutions
    const hash = window.location.hash;
    if (hash.startsWith('#share=')) {
      try {
        const encodedData = hash.replace('#share=', '');
        const decodedData = JSON.parse(atob(encodedData));
        setCurrentSolution(decodedData);
        setInput(decodedData.problem || '');
        showNotification("Shared solution loaded!", "success");
        // Clear hash without reload
        window.history.replaceState(null, '', window.location.pathname);
      } catch (e) {
        console.error("Failed to decode shared solution", e);
        showNotification("Could not load shared link.", "error");
      }
    }
  }, []);

  // Save history to localStorage
  useEffect(() => {
    localStorage.setItem('math_master_history', JSON.stringify(history));
  }, [history]);

  const showNotification = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const handleSolve = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() && !image) return;

    setLoading(true);
    setCurrentSolution(null);
    try {
      const solution = await solveMathProblem(input, image || undefined);
      setCurrentSolution(solution);
      
      const newHistoryItem: HistoryItem = {
        id: Date.now().toString(),
        timestamp: Date.now(),
        problem: input || "Problem from image",
        solution: solution,
      };
      setHistory(prev => [newHistoryItem, ...prev].slice(0, 20)); // Keep last 20
    } catch (error: any) {
      showNotification(error.message || "Failed to solve problem", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleCopySolution = async () => {
    if (!currentSolution) return;

    const stepsText = currentSolution.steps.map((step, i) => `Step ${i + 1}: ${step}`).join('\n');
    const fullText = `Problem: ${currentSolution.problem}\n\nExplanation: ${currentSolution.explanation}\n\nSolution Steps:\n${stepsText}\n\nFinal Answer: ${currentSolution.finalAnswer}\n\nSolved by Math Master AI`;

    try {
      await navigator.clipboard.writeText(fullText);
      showNotification("Solution copied to clipboard!");
    } catch (err) {
      showNotification("Failed to copy solution", "error");
    }
  };

  const handleShare = async () => {
    if (!currentSolution) return;

    try {
      // Encode solution data into a shareable URL
      const dataStr = JSON.stringify(currentSolution);
      const encoded = btoa(unescape(encodeURIComponent(dataStr)));
      const shareUrl = `${window.location.origin}${window.location.pathname}#share=${encoded}`;

      if (navigator.share) {
        await navigator.share({
          title: 'Math Master AI Solution',
          text: `Check out this math solution for: ${currentSolution.problem}`,
          url: shareUrl,
        });
      } else {
        await navigator.clipboard.writeText(shareUrl);
        showNotification("Link copied to clipboard!");
      }
    } catch (err) {
      console.error("Error sharing:", err);
      // Fallback for clipboard if sharing is cancelled or fails
      try {
        const dataStr = JSON.stringify(currentSolution);
        const encoded = btoa(unescape(encodeURIComponent(dataStr)));
        const shareUrl = `${window.location.origin}${window.location.pathname}#share=${encoded}`;
        await navigator.clipboard.writeText(shareUrl);
        showNotification("Link copied to clipboard!");
      } catch (clipboardErr) {
        showNotification("Failed to share link", "error");
      }
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setImage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const selectHistoryItem = (item: HistoryItem) => {
    setCurrentSolution(item.solution);
    setInput(item.problem);
    setIsSidebarOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-slate-50 font-sans text-slate-900">
      {/* Toast Notification */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 px-6 py-3 rounded-xl shadow-2xl flex items-center space-x-3 animate-in slide-in-from-bottom-5 duration-300 ${
          toast.type === 'error' ? 'bg-red-600 text-white' : 'bg-slate-800 text-white'
        }`}>
          {toast.type === 'success' ? (
            <svg className="w-5 h-5 text-emerald-400" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
          ) : (
            <svg className="w-5 h-5 text-red-200" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
            </svg>
          )}
          <span className="font-medium">{toast.message}</span>
        </div>
      )}

      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between p-4 bg-indigo-600 text-white shadow-lg sticky top-0 z-20">
        <h1 className="text-xl font-bold">Math Master AI</h1>
        <button 
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="p-2 bg-white/10 rounded-md"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
          </svg>
        </button>
      </div>

      {/* Sidebar - Desktop & Mobile Overlay */}
      <div className={`${isSidebarOpen ? 'fixed inset-0 z-30' : 'hidden'} md:block md:sticky md:top-0 md:h-screen shadow-2xl md:shadow-none`}>
        <div className="flex h-full">
          <HistorySidebar 
            history={history} 
            onSelect={selectHistoryItem} 
            onClear={() => setHistory([])} 
          />
          {isSidebarOpen && (
            <div 
              className="flex-1 bg-black/50 md:hidden" 
              onClick={() => setIsSidebarOpen(false)}
            />
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col items-center p-4 md:p-8 max-w-4xl mx-auto w-full">
        {/* Hero Section */}
        <div className="w-full text-center mb-10 hidden md:block">
          <h1 className="text-4xl font-extrabold text-slate-800 mb-2">
            Math <span className="text-indigo-600">Master</span> AI
          </h1>
          <p className="text-slate-500">Your personal mathematical problem solver for all levels.</p>
        </div>

        {/* Input Card */}
        <div className="w-full bg-white rounded-2xl shadow-xl p-6 mb-8 border border-slate-100 transition-all">
          <form onSubmit={handleSolve} className="space-y-4">
            <div className="relative">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your math problem here... (e.g., Solve 2x + 5 = 15 or Integrate x^2 dx)"
                className="w-full min-h-[120px] p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all resize-none text-lg"
              />
              
              <div className="absolute bottom-3 right-3 flex space-x-2">
                <input 
                  type="file" 
                  accept="image/*" 
                  className="hidden" 
                  ref={fileInputRef} 
                  onChange={handleImageUpload}
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="p-2 bg-slate-200 hover:bg-slate-300 rounded-lg text-slate-600 transition-colors"
                  title="Upload problem image"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </button>
              </div>
            </div>

            {image && (
              <div className="relative inline-block mt-2">
                <img src={image} alt="Preview" className="max-h-48 rounded-lg border border-slate-200" />
                <button 
                  onClick={removeImage}
                  className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 shadow-lg hover:bg-red-600"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            )}

            <button
              type="submit"
              disabled={loading || (!input.trim() && !image)}
              className={`w-full py-4 rounded-xl font-bold text-lg text-white transition-all shadow-lg flex items-center justify-center space-x-2 
                ${loading 
                  ? 'bg-slate-400 cursor-not-allowed' 
                  : 'bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98]'}`}
            >
              {loading ? (
                <>
                  <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  <span>Calculating...</span>
                </>
              ) : (
                <>
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                  </svg>
                  <span>Solve with AI</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Results Section */}
        {currentSolution && (
          <div className="w-full space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Header / Info */}
            <div className="flex flex-wrap gap-2 items-center justify-between">
              <div className="flex gap-2">
                <span className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-sm font-medium">
                  {currentSolution.topic}
                </span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  currentSolution.difficulty === 'Hard' ? 'bg-red-100 text-red-700' :
                  currentSolution.difficulty === 'Medium' ? 'bg-amber-100 text-amber-700' :
                  'bg-green-100 text-green-700'
                }`}>
                  {currentSolution.difficulty}
                </span>
              </div>
              
              <div className="flex gap-2">
                <button 
                  onClick={handleCopySolution}
                  className="flex items-center space-x-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-slate-600 font-semibold hover:bg-slate-50 transition-colors shadow-sm active:scale-95"
                  title="Copy full solution text"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m-3 8h3m-3 4h3m-6-4h.01M9 16h.01" />
                  </svg>
                  <span>Copy</span>
                </button>
                <button 
                  onClick={handleShare}
                  className="flex items-center space-x-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-slate-600 font-semibold hover:bg-slate-50 transition-colors shadow-sm active:scale-95"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6a3 3 0 100 2.684m6.632-3.316a3 3 0 110 2.684m0-2.684l-6.632-3.316" />
                  </svg>
                  <span>Share</span>
                </button>
              </div>
            </div>

            {/* Main Solution Card */}
            <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-100">
              <div className="p-6 bg-indigo-600 text-white">
                <h2 className="text-xl font-bold flex items-center space-x-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                  </svg>
                  <span>Problem Summary</span>
                </h2>
                <p className="mt-2 text-indigo-50 font-medium italic">"{currentSolution.problem}"</p>
              </div>
              
              <div className="p-6 space-y-8">
                {/* Explanation */}
                <section>
                  <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-2">The Concept</h3>
                  <p className="text-slate-700 leading-relaxed text-lg">
                    {currentSolution.explanation}
                  </p>
                </section>

                {/* Graph (if applicable) */}
                {currentSolution.graphData && currentSolution.graphData.length > 0 && (
                  <section>
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-2">Visualization</h3>
                    <GraphView data={currentSolution.graphData} />
                  </section>
                )}

                {/* Steps */}
                <section>
                  <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Step-by-Step Solution</h3>
                  <div className="space-y-4">
                    {currentSolution.steps.map((step, idx) => (
                      <div key={idx} className="flex group">
                        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-100 text-slate-500 font-bold flex items-center justify-center mr-4 group-hover:bg-indigo-100 group-hover:text-indigo-600 transition-colors">
                          {idx + 1}
                        </div>
                        <div className="flex-1 pb-4 border-b border-slate-100 group-last:border-none">
                          <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">{step}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>

                {/* Final Answer */}
                <section className="bg-emerald-50 rounded-xl p-6 border-2 border-emerald-100">
                  <h3 className="text-sm font-bold text-emerald-600 uppercase tracking-widest mb-2">Final Answer</h3>
                  <div className="text-2xl font-black text-slate-800">
                    {currentSolution.finalAnswer}
                  </div>
                </section>
              </div>
            </div>
          </div>
        )}

        {/* Empty State */}
        {!currentSolution && !loading && (
          <div className="mt-20 text-center space-y-6 opacity-60">
            <div className="inline-block p-6 rounded-full bg-slate-200">
              <svg className="w-16 h-16 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z" />
              </svg>
            </div>
            <h2 className="text-2xl font-semibold text-slate-500">Ready to solve any math problem!</h2>
            <p className="max-w-md mx-auto text-slate-400">
              Try typing an equation, describing a word problem, or uploading a picture of your homework. 
              Our AI handles everything from basic arithmetic to advanced calculus.
            </p>
          </div>
        )}
      </main>
      
      {/* Footer (Floating) */}
      <footer className="fixed bottom-0 left-0 right-0 p-4 md:static md:p-8 text-center text-xs text-slate-400 pointer-events-none">
        <div className="bg-white/80 backdrop-blur-sm p-2 rounded-full inline-block shadow-sm border border-slate-100 pointer-events-auto">
          Powered by Gemini 3 Pro • Math Master AI v1.0
        </div>
      </footer>
    </div>
  );
};

export default App;
