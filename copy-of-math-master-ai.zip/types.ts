
export interface MathSolution {
  problem: string;
  explanation: string;
  steps: string[];
  finalAnswer: string;
  graphData?: Array<{ x: number; y: number }>;
  topic?: string;
  difficulty?: 'Easy' | 'Medium' | 'Hard';
}

export interface HistoryItem {
  id: string;
  timestamp: number;
  problem: string;
  solution: MathSolution;
}
